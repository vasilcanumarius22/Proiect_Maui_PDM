using MAUI_PROJECT_PDM.Models;

namespace MAUI_PROJECT_PDM.Views;

public partial class AboutUs : ContentPage
{
	public AboutUs()
	{
		InitializeComponent();
	}
}