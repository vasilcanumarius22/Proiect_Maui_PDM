﻿namespace MAUI_PROJECT_PDM;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
